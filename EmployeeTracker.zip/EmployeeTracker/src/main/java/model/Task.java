package model;

public class Task {
    private int taskId;
    private int employeeId;
    private String taskName;
    private String taskCategory;
    private String description;
    private String startTime;
    private String endTime;
    private double duration;
    private String taskDate;

    // Constructor, getters, and setters
    // Constructor
}

package model;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.Duration;
import java.time.LocalTime;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/AddTaskServlet")
public class addtask extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("employeeId") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int employeeId = (int) session.getAttribute("employeeId");
        String taskName = request.getParameter("taskName");
        String taskCategory = request.getParameter("taskCategory");
        String description = request.getParameter("description");
        String taskDate = request.getParameter("taskDate");

        // Calculate duration
        LocalTime startTime = LocalTime.parse(request.getParameter("startTime"));
        LocalTime endTime = LocalTime.parse(request.getParameter("endTime"));
        Duration duration = Duration.between(startTime, endTime);
        double hours = duration.toMinutes() / 60.0;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/employees", "root", "1234");

            String sql = "INSERT INTO Tasks (employeeId, taskName, taskCategory, description, startTime, endTime, duration, taskDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, employeeId);
            ps.setString(2, taskName);
            ps.setString(3, taskCategory);
            ps.setString(4, description);
            ps.setString(5, startTime.toString());
            ps.setString(6, endTime.toString());
            ps.setDouble(7, hours);
            ps.setString(8, taskDate);

            int result = ps.executeUpdate();
            if (result > 0) {
                response.sendRedirect("veiwtask.jsp");
            } else {
                response.getWriter().println("Failed to add task, please try again.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

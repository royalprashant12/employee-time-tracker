package model;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/ViewTasksServlet")
public class veiwtask extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public class Task {
        private int taskId;
        private int employeeId;
        private String taskName;
        private String taskCategory;
        private String description;
        private String startTime;
        private String endTime;
        private double duration;
        private String taskDate;

        // Constructor, getters, and setters for Task class
        // Constructor
        public Task(int taskId, int employeeId, String taskName, String taskCategory, String description, String startTime, String endTime, double duration, String taskDate) {
            this.taskId = taskId;
            this.employeeId = employeeId;
            this.taskName = taskName;
            this.taskCategory = taskCategory;
            this.description = description;
            this.startTime = startTime;
            this.endTime = endTime;
            this.duration = duration;
            this.taskDate = taskDate;
        }

        // Getters and setters
        // Getters
        public int getTaskId() {
            return taskId;
        }

        public int getEmployeeId() {
            return employeeId;
        }

        public String getTaskName() {
            return taskName;
        }

        public String getTaskCategory() {
            return taskCategory;
        }

        public String getDescription() {
            return description;
        }

        public String getStartTime() {
            return startTime;
        }

        public String getEndTime() {
            return endTime;
        }

        public double getDuration() {
            return duration;
        }

        public String getTaskDate() {
            return taskDate;
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("id") == null) {
            response.sendRedirect("elogin.jsp");
            return;
        }

        int employeeId = (int) session.getAttribute("id");
        List<Task> tasks = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/employees", "root", "1234");

            String sql = "SELECT * FROM Tasks WHERE employeeId = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, employeeId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int taskId = rs.getInt("taskId");
                String taskName = rs.getString("taskName");
                String taskCategory = rs.getString("taskCategory");
                String description = rs.getString("description");
                String startTime = rs.getString("startTime");
                String endTime = rs.getString("endTime");
                double duration = rs.getDouble("duration");
                String taskDate = rs.getString("taskDate");

                Task task = new Task(taskId, employeeId, taskName, taskCategory, description, startTime, endTime, duration, taskDate);
                tasks.add(task);
            }

            conn.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        request.setAttribute("tasks", tasks);
        request.getRequestDispatcher("viewtask.jsp").forward(request, response);
    }
}
